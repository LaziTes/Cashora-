import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MetricCard } from "@/types/dashboard"

interface MetricCardProps {
  data: MetricCard
}

export function MetricCardComponent({ data }: MetricCardProps) {
  return (
    <Card className="bg-[#0B0D1D] border-[#1D2144]">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-400">{data.label}</CardTitle>
        <data.icon className="h-4 w-4 text-gray-400" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold text-white">{data.value}</div>
      </CardContent>
    </Card>
  )
}

