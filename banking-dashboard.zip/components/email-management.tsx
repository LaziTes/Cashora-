"use client"

import { useState } from 'react'
import { User } from '@/types/dashboard'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from "@/components/ui/checkbox"

// Mock data
const mockUsers: User[] = [
  { id: '1', firstName: 'John', lastName: 'Doe', username: 'johndoe', email: 'john@example.com', dateOfBirth: '1990-01-01', placeOfBirth: 'Addis Ababa', residence: 'Addis Ababa', nationality: 'Ethiopian', idCardUrl: '', role: 'user', status: 'approved', balance: 1000, withdrawalLimit: { daily: 1000, weekly: 5000, monthly: 20000 }, sendLimit: { daily: 1000, weekly: 5000, monthly: 20000 } },
  { id: '2', firstName: 'Jane', lastName: 'Doe', username: 'janedoe', email: 'jane@example.com', dateOfBirth: '1992-05-15', placeOfBirth: 'Bahir Dar', residence: 'Addis Ababa', nationality: 'Ethiopian', idCardUrl: '', role: 'user', status: 'approved', balance: 2000, withdrawalLimit: { daily: 1000, weekly: 5000, monthly: 20000 }, sendLimit: { daily: 1000, weekly: 5000, monthly: 20000 } },
]

export function EmailManagement() {
  const [selectedUsers, setSelectedUsers] = useState<string[]>([])
  const [subject, setSubject] = useState<string>('')
  const [body, setBody] = useState<string>('')

  const handleSendEmail = () => {
    // Here you would typically integrate with an email service
    console.log(`Sending email to ${selectedUsers.length === mockUsers.length ? 'all users' : selectedUsers.join(', ')}`)
    console.log(`Subject: ${subject}`)
    console.log(`Body: ${body}`)
    // Reset form
    setSelectedUsers([])
    setSubject('')
    setBody('')
  }

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedUsers(mockUsers.map(user => user.id))
    } else {
      setSelectedUsers([])
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Email Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <Checkbox
              id="selectAll"
              checked={selectedUsers.length === mockUsers.length}
              onCheckedChange={handleSelectAll}
            />
            <label htmlFor="selectAll" className="ml-2">Select All Users</label>
          </div>
          {mockUsers.map((user) => (
            <div key={user.id}>
              <Checkbox
                id={user.id}
                checked={selectedUsers.includes(user.id)}
                onCheckedChange={(checked) => {
                  if (checked) {
                    setSelectedUsers([...selectedUsers, user.id])
                  } else {
                    setSelectedUsers(selectedUsers.filter(id => id !== user.id))
                  }
                }}
              />
              <label htmlFor={user.id} className="ml-2">{user.firstName} {user.lastName} ({user.email})</label>
            </div>
          ))}
          <Input
            placeholder="Subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />
          <Textarea
            placeholder="Email body"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            rows={5}
          />
          <Button onClick={handleSendEmail}>Send Email</Button>
        </div>
      </CardContent>
    </Card>
  )
}

