"use client"

import { useState } from 'react'
import { Transaction } from '@/types/dashboard'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'

// Mock data
const mockSendingRequests: Transaction[] = [
  { id: '1', userId: '1', type: 'send', amount: 200, status: 'pending', createdAt: '2023-06-01', updatedAt: '2023-06-01' },
  { id: '2', userId: '2', type: 'send', amount: 300, status: 'pending', createdAt: '2023-06-02', updatedAt: '2023-06-02' },
]

export function SendingRequests() {
  const [sendingRequests, setSendingRequests] = useState<Transaction[]>(mockSendingRequests)
  const [rejectionReason, setRejectionReason] = useState('')

  const handleApprove = (requestId: string) => {
    const updatedRequests = sendingRequests.map(r => 
      r.id === requestId 
        ? { ...r, status: 'approved', updatedAt: new Date().toISOString() }
        : r
    )
    setSendingRequests(updatedRequests)
    // Here you would typically send an email notification to the user
    console.log(`Approved sending request for user ${requestId}`)
  }

  const handleReject = (requestId: string) => {
    if (rejectionReason) {
      const updatedRequests = sendingRequests.map(r => 
        r.id === requestId 
          ? { ...r, status: 'rejected', rejectionReason, updatedAt: new Date().toISOString() }
          : r
      )
      setSendingRequests(updatedRequests)
      setRejectionReason('')
      // Here you would typically send an email notification to the user
      console.log(`Rejected sending request for user ${requestId}. Reason: ${rejectionReason}`)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Sending Requests</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User ID</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Created At</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sendingRequests.map((request) => (
              <TableRow key={request.id}>
                <TableCell>{request.userId}</TableCell>
                <TableCell>${request.amount}</TableCell>
                <TableCell>{request.status}</TableCell>
                <TableCell>{new Date(request.createdAt).toLocaleDateString()}</TableCell>
                <TableCell>
                  {request.status === 'pending' && (
                    <>
                      <Button variant="outline" className="mr-2" onClick={() => handleApprove(request.id)}>
                        Approve
                      </Button>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline">Reject</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Reject Sending Request</DialogTitle>
                          </DialogHeader>
                          <Textarea
                            placeholder="Reason for rejection"
                            value={rejectionReason}
                            onChange={(e) => setRejectionReason(e.target.value)}
                          />
                          <Button onClick={() => handleReject(request.id)}>Confirm Rejection</Button>
                        </DialogContent>
                      </Dialog>
                    </>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

