"use client"

import { useState } from 'react'
import { MoreHorizontal, Pencil, Trash2, Filter } from 'lucide-react'

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const initialTransactions = [
  {
    id: '1',
    client: {
      name: "John Carter",
      email: "hello@johncarter.com"
    },
    date: "Jan 30, 2024",
    status: "Accepted",
    type: "Send to Matt",
    amount: 1099.24
  },
  {
    id: '2',
    client: {
      name: "Sophie Moore",
      email: "contact@sophiemoore.com"
    },
    date: "Jan 27, 2024",
    status: "Rejected",
    type: "Deposit",
    amount: 5870.32
  },
  {
    id: '3',
    client: {
      name: "Matt Cannon",
      email: "hi@mattcannon.com"
    },
    date: "Jan 24, 2024",
    status: "Accepted",
    type: "Withdrawal",
    amount: 13899.48
  },
  {
    id: '4',
    client: {
      name: "Graham Hills",
      email: "hi@grahamhills.com"
    },
    date: "Jan 21, 2024",
    status: "Pending",
    type: "Send to moore",
    amount: 1569.12
  },
  {
    id: '5',
    client: {
      name: "Sandy Houston",
      email: "contact@sandyhouston.com"
    },
    date: "Jan 18, 2024",
    status: "Accepted",
    type: "Deposit",
    amount: 899.16
  },
  {
    id: '6',
    client: {
      name: "Andy Smith",
      email: "hello@andysmith.com"
    },
    date: "Jan 15, 2024",
    status: "Pending",
    type: "Withdrawal",
    amount: 2449.64
  }
]

export function TransactionsTable() {
  const [transactions, setTransactions] = useState(initialTransactions)
  const [filter, setFilter] = useState({
    status: 'all',
    type: 'all',
    search: ''
  })

  const handleDelete = (id: string) => {
    setTransactions(transactions.filter(t => t.id !== id))
  }

  const handleEdit = (id: string, newData: any) => {
    setTransactions(transactions.map(t => t.id === id ? { ...t, ...newData } : t))
  }

  const filteredTransactions = transactions.filter(t => 
    (filter.status === 'all' || t.status === filter.status) &&
    (filter.type === 'all' || t.type === filter.type) &&
    (filter.search ? t.client.name.toLowerCase().includes(filter.search.toLowerCase()) : true)
  )

  return (
    <div>
      <div className="flex space-x-2 mb-4">
        <Select onValueChange={(value) => setFilter({...filter, status: value})}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="Accepted">Accepted</SelectItem>
            <SelectItem value="Rejected">Rejected</SelectItem>
            <SelectItem value="Pending">Pending</SelectItem>
          </SelectContent>
        </Select>
        <Select onValueChange={(value) => setFilter({...filter, type: value})}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="Deposit">Deposit</SelectItem>
            <SelectItem value="Withdrawal">Withdrawal</SelectItem>
            <SelectItem value="Send">Send</SelectItem>
          </SelectContent>
        </Select>
        <Input 
          placeholder="Search by name" 
          value={filter.search}
          onChange={(e) => setFilter({...filter, search: e.target.value})}
          className="w-[200px]"
        />
      </div>
      <Table>
        <TableHeader>
          <TableRow className="border-[#1D2144]">
            <TableHead className="text-gray-400">Client</TableHead>
            <TableHead className="text-gray-400">Date</TableHead>
            <TableHead className="text-gray-400">Status</TableHead>
            <TableHead className="text-gray-400">Transaction Type</TableHead>
            <TableHead className="text-right text-gray-400">Amount</TableHead>
            <TableHead className="text-gray-400"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredTransactions.map((transaction) => (
            <TableRow key={transaction.id} className="border-[#1D2144]">
              <TableCell>
                <div className="flex flex-col">
                  <span className="font-medium text-white">{transaction.client.name}</span>
                  <span className="text-sm text-gray-400">
                    {transaction.client.email}
                  </span>
                </div>
              </TableCell>
              <TableCell className="text-gray-400">{transaction.date}</TableCell>
              <TableCell>
                <Badge
                  variant={
                    transaction.status === "Accepted"
                      ? "success"
                      : transaction.status === "Rejected"
                      ? "destructive"
                      : "warning"
                  }
                  className={
                    transaction.status === "Accepted"
                      ? "bg-green-500/10 text-green-500"
                      : transaction.status === "Rejected"
                      ? "bg-red-500/10 text-red-500"
                      : "bg-yellow-500/10 text-yellow-500"
                  }
                >
                  {transaction.status}
                </Badge>
              </TableCell>
              <TableCell className="text-gray-400">{transaction.type}</TableCell>
              <TableCell className="text-right text-white">
                ${transaction.amount.toFixed(2)}
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Open menu</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-[#0B0D1D] border-[#1D2144]">
                    <DropdownMenuItem 
                      className="text-gray-400 hover:text-white"
                      onClick={() => handleEdit(transaction.id, { status: 'Accepted' })}
                    >
                      <Pencil className="mr-2 h-4 w-4" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      className="text-gray-400 hover:text-white"
                      onClick={() => handleDelete(transaction.id)}
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

