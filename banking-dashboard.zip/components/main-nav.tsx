"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useRouter } from 'next/navigation'
import { BanknoteIcon as Bank, BarChart3, Mail, Menu, Send, LogOut, Users, User } from 'lucide-react'

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function MainNav() {
  const pathname = usePathname()
  const router = useRouter()

  const routes = [
    {
      label: "Dashboard",
      icon: BarChart3,
      href: "/",
      color: "text-orange-500"
    },
    {
      label: "Banks",
      icon: Bank,
      href: "/banks",
      color: "text-sky-500"
    },
    {
      label: "Users",
      icon: Users,
      href: "/users",
      color: "text-violet-500"
    },
    {
      label: "Withdrawal Requests",
      icon: Send,
      href: "/withdrawal-requests",
      color: "text-pink-500"
    },
    {
      label: "Deposit Requests",
      icon: Send,
      href: "/deposit-requests",
      color: "text-green-500"
    },
    {
      label: "Sending Requests",
      icon: Send,
      href: "/sending-requests",
      color: "text-blue-500"
    },
    {
      label: "Emails",
      icon: Mail,
      href: "/emails",
      color: "text-purple-500"
    },
    {
      label: "Transactions",
      icon: BarChart3,
      href: "/transactions",
      color: "text-yellow-500"
    },
    {
      label: "Profile",
      icon: User,
      href: "/profile",
      color: "text-gray-500"
    }
  ]

  const handleLogout = () => {
    console.log('Logging out...')
    router.push('/login')
  }

  const NavContent = () => (
    <div className="flex h-full w-full flex-col gap-4">
      <div className="flex h-16 items-center px-4">
        <h1 className="text-2xl font-bold text-orange-500">CASHORA</h1>
      </div>
      <div className="space-y-4">
        <div className="px-3">
          <Input placeholder="Search for..." className="bg-navy-800" />
        </div>
        <nav className="flex flex-col space-y-1">
          {routes.map((route) => (
            <Button
              key={route.href}
              variant="ghost"
              className={cn(
                "w-full justify-start gap-2",
                pathname === route.href && "bg-muted"
              )}
              asChild
            >
              <Link href={route.href}>
                <route.icon className={cn("h-5 w-5", route.color)} />
                {route.label}
              </Link>
            </Button>
          ))}
        </nav>
        <div className="mt-auto p-4">
          <Button onClick={handleLogout} className="w-full">
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
    </div>
  )

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden lg:flex w-64 flex-col gap-4 border-r bg-navy-900">
        <NavContent />
      </div>
      {/* Mobile Sidebar */}
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden">
            <Menu className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 bg-navy-900 p-0">
          <NavContent />
        </SheetContent>
      </Sheet>
    </>
  )
}

