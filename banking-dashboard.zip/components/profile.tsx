"use client"

import { useState } from 'react'
import { User } from '@/types/dashboard'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

// Mock admin data
const mockAdmin: User = {
  id: 'admin1',
  firstName: 'Admin',
  lastName: 'User',
  username: 'admin',
  email: 'admin@example.com',
  dateOfBirth: '1985-01-01',
  placeOfBirth: 'Addis Ababa',
  residence: 'Addis Ababa',
  nationality: 'Ethiopian',
  idCardUrl: '/placeholder.svg?height=300&width=200',
  role: 'admin',
  status: 'approved',
  balance: 0,
  withdrawalLimit: { daily: 0, weekly: 0, monthly: 0, yearly: 0 },
  sendLimit: { daily: 0, weekly: 0, monthly: 0, yearly: 0 },
}

export function ProfileComponent() {
  const [admin, setAdmin] = useState<User>(mockAdmin)
  const [isEditing, setIsEditing] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setAdmin(prev => ({ ...prev, [name]: value }))
  }

  const handleSave = () => {
    // Here you would typically send the updated admin data to your backend
    console.log('Saving admin data:', admin)
    setIsEditing(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Admin Profile</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <label className="font-bold">First Name:</label>
            {isEditing ? (
              <Input
                name="firstName"
                value={admin.firstName}
                onChange={handleInputChange}
              />
            ) : (
              <p>{admin.firstName}</p>
            )}
          </div>
          <div>
            <label className="font-bold">Last Name:</label>
            {isEditing ? (
              <Input
                name="lastName"
                value={admin.lastName}
                onChange={handleInputChange}
              />
            ) : (
              <p>{admin.lastName}</p>
            )}
          </div>
          <div>
            <label className="font-bold">Username:</label>
            <p>{admin.username}</p>
          </div>
          <div>
            <label className="font-bold">Email:</label>
            {isEditing ? (
              <Input
                name="email"
                value={admin.email}
                onChange={handleInputChange}
              />
            ) : (
              <p>{admin.email}</p>
            )}
          </div>
          <div>
            <label className="font-bold">Date of Birth:</label>
            <p>{admin.dateOfBirth}</p>
          </div>
          <div>
            <label className="font-bold">Place of Birth:</label>
            <p>{admin.placeOfBirth}</p>
          </div>
          <div>
            <label className="font-bold">Residence:</label>
            {isEditing ? (
              <Input
                name="residence"
                value={admin.residence}
                onChange={handleInputChange}
              />
            ) : (
              <p>{admin.residence}</p>
            )}
          </div>
          <div>
            <label className="font-bold">Nationality:</label>
            <p>{admin.nationality}</p>
          </div>
          {isEditing ? (
            <Button onClick={handleSave}>Save</Button>
          ) : (
            <Button onClick={() => setIsEditing(true)}>Edit</Button>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

