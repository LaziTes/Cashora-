"use client"

import { useState } from 'react'
import { Settings } from '@/types/dashboard'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

const initialSettings: Settings = {
  withdrawalFee: {
    type: 'percentage',
    value: 2,
  },
  sendFee: {
    type: 'fixed',
    value: 1,
  },
}

export function SettingsManagement() {
  const [settings, setSettings] = useState<Settings>(initialSettings)

  const handleSaveSettings = () => {
    // Here you would typically save the settings to your backend
    console.log('Saving settings:', settings)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Settings</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <h3 className="text-lg font-medium">Withdrawal Fee</h3>
            <Select
              onValueChange={(value) => setSettings({...settings, withdrawalFee: {...settings.withdrawalFee, type: value as 'percentage' | 'fixed'}})}
              value={settings.withdrawalFee.type}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select fee type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="percentage">Percentage</SelectItem>
                <SelectItem value="fixed">Fixed</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={settings.withdrawalFee.value}
              onChange={(e) => setSettings({...settings, withdrawalFee: {...settings.withdrawalFee, value: parseFloat(e.target.value)}})}
              className="mt-2"
            />
          </div>
          <div>
            <h3 className="text-lg font-medium">Send Fee</h3>
            <Select
              onValueChange={(value) => setSettings({...settings, sendFee: {...settings.sendFee, type: value as 'percentage' | 'fixed'}})}
              value={settings.sendFee.type}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select fee type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="percentage">Percentage</SelectItem>
                <SelectItem value="fixed">Fixed</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={settings.sendFee.value}
              onChange={(e) => setSettings({...settings, sendFee: {...settings.sendFee, value: parseFloat(e.target.value)}})}
              className="mt-2"
            />
          </div>
          <Button onClick={handleSaveSettings}>Save Settings</Button>
        </div>
      </CardContent>
    </Card>
  )
}

