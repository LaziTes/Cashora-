"use client"

import { useState } from 'react'
import { Transaction } from '@/types/dashboard'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { ScrollArea } from "@/components/ui/scroll-area"

// Mock data
const mockDeposits: Transaction[] = [
  { id: '1', userId: 'John Doe', type: 'deposit', amount: 1000, status: 'pending', createdAt: '2023-06-01', updatedAt: '2023-06-01', receiptUrl: '/placeholder.svg?height=300&width=200' },
  { id: '2', userId: 'Jane Smith', type: 'deposit', amount: 500, status: 'pending', createdAt: '2023-06-02', updatedAt: '2023-06-02', receiptUrl: '/placeholder.svg?height=300&width=200' },
]

export function DepositRequests() {
  const [deposits, setDeposits] = useState<Transaction[]>(mockDeposits)
  const [rejectionReason, setRejectionReason] = useState('')

  const handleApprove = (depositId: string) => {
    const updatedDeposits = deposits.map(d => 
      d.id === depositId 
        ? { ...d, status: 'approved', updatedAt: new Date().toISOString() }
        : d
    )
    setDeposits(updatedDeposits)
    // Here you would typically send an email notification to the user
    console.log(`Approved deposit for user ${depositId}`)
  }

  const handleReject = (depositId: string) => {
    if (rejectionReason) {
      const updatedDeposits = deposits.map(d => 
        d.id === depositId 
          ? { ...d, status: 'rejected', rejectionReason, updatedAt: new Date().toISOString() }
          : d
      )
      setDeposits(updatedDeposits)
      setRejectionReason('')
      // Here you would typically send an email notification to the user
      console.log(`Rejected deposit for user ${depositId}. Reason: ${rejectionReason}`)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Deposit Requests</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Created At</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {deposits.map((deposit) => (
              <TableRow key={deposit.id}>
                <TableCell>{deposit.userId}</TableCell>
                <TableCell>${deposit.amount}</TableCell>
                <TableCell>{deposit.status}</TableCell>
                <TableCell>{new Date(deposit.createdAt).toLocaleDateString()}</TableCell>
                <TableCell>
                  {deposit.status === 'pending' && (
                    <>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="mr-2">View Receipt</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-3xl max-h-[80vh]">
                          <DialogHeader>
                            <DialogTitle>Transaction Receipt</DialogTitle>
                          </DialogHeader>
                          <ScrollArea className="h-full w-full">
                            <img src={deposit.receiptUrl} alt="Receipt" className="max-w-full h-auto" />
                          </ScrollArea>
                          <Button onClick={() => handleApprove(deposit.id)}>Approve</Button>
                        </DialogContent>
                      </Dialog>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline">Reject</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Reject Deposit</DialogTitle>
                          </DialogHeader>
                          <Textarea
                            placeholder="Reason for rejection"
                            value={rejectionReason}
                            onChange={(e) => setRejectionReason(e.target.value)}
                          />
                          <Button onClick={() => handleReject(deposit.id)}>Confirm Rejection</Button>
                        </DialogContent>
                      </Dialog>
                    </>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

