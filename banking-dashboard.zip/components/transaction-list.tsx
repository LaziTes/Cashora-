"use client"

import { useState } from 'react'
import { Transaction } from '@/types/dashboard'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

// Mock data
const mockTransactions: Transaction[] = [
  { id: '1', userId: '1', type: 'deposit', amount: 1000, status: 'approved', createdAt: '2023-06-01', updatedAt: '2023-06-01', receiptUrl: '/placeholder.svg?height=300&width=200' },
  { id: '2', userId: '2', type: 'withdrawal', amount: 500, status: 'pending', createdAt: '2023-06-02', updatedAt: '2023-06-02' },
  { id: '3', userId: '3', type: 'send', amount: 250, status: 'approved', createdAt: '2023-06-03', updatedAt: '2023-06-03' },
]

export function TransactionList() {
  const [transactions, setTransactions] = useState<Transaction[]>(mockTransactions)
  const [filter, setFilter] = useState<'all' | 'deposit' | 'withdrawal' | 'send'>('all')
  const [search, setSearch] = useState('')

  const filteredTransactions = transactions.filter(transaction => 
    (filter === 'all' || transaction.type === filter) &&
    (transaction.userId.includes(search) || transaction.id.includes(search))
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle>Transaction List</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex space-x-2 mb-4">
          <Select onValueChange={(value) => setFilter(value as 'all' | 'deposit' | 'withdrawal' | 'send')}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All</SelectItem>
              <SelectItem value="deposit">Deposit</SelectItem>
              <SelectItem value="withdrawal">Withdrawal</SelectItem>
              <SelectItem value="send">Send</SelectItem>
            </SelectContent>
          </Select>
          <Input
            placeholder="Search by User ID or Transaction ID"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Transaction ID</TableHead>
              <TableHead>User ID</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Created At</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTransactions.map((transaction) => (
              <TableRow key={transaction.id}>
                <TableCell>{transaction.id}</TableCell>
                <TableCell>{transaction.userId}</TableCell>
                <TableCell>{transaction.type}</TableCell>
                <TableCell>${transaction.amount}</TableCell>
                <TableCell>{transaction.status}</TableCell>
                <TableCell>{new Date(transaction.createdAt).toLocaleDateString()}</TableCell>
                <TableCell>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline">View Details</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Transaction Details</DialogTitle>
                      </DialogHeader>
                      <div>
                        <p>Transaction ID: {transaction.id}</p>
                        <p>User ID: {transaction.userId}</p>
                        <p>Type: {transaction.type}</p>
                        <p>Amount: ${transaction.amount}</p>
                        <p>Status: {transaction.status}</p>
                        <p>Created At: {new Date(transaction.createdAt).toLocaleString()}</p>
                        <p>Updated At: {new Date(transaction.updatedAt).toLocaleString()}</p>
                        {transaction.receiptUrl && (
                          <img src={transaction.receiptUrl} alt="Receipt" className="max-w-full h-auto mt-2" />
                        )}
                      </div>
                    </DialogContent>
                  </Dialog>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

