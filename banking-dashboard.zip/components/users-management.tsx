"use client"

import { useState } from 'react'
import { User } from '@/types/dashboard'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Textarea } from "@/components/ui/textarea"

// Mock data
const mockUsers: User[] = [
  { id: '1', firstName: 'John', lastName: 'Doe', username: 'johndoe', email: 'john@example.com', dateOfBirth: '1990-01-01', placeOfBirth: 'Addis Ababa', residence: 'Addis Ababa', nationality: 'Ethiopian', idCardUrl: '/placeholder.svg?height=300&width=200', role: 'user', status: 'approved', balance: 1000, withdrawalLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 }, sendLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 } },
  { id: '2', firstName: 'Jane', lastName: 'Doe', username: 'janedoe', email: 'jane@example.com', dateOfBirth: '1992-05-15', placeOfBirth: 'Bahir Dar', residence: 'Addis Ababa', nationality: 'Ethiopian', idCardUrl: '/placeholder.svg?height=300&width=200', role: 'user', status: 'pending', balance: 2000, withdrawalLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 }, sendLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 } },
]

export function UsersManagement() {
  const [users, setUsers] = useState<User[]>(mockUsers)
  const [newUser, setNewUser] = useState<Partial<User>>({ role: 'user' })
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [balanceAction, setBalanceAction] = useState<'add' | 'deduct'>('add')
  const [balanceAmount, setBalanceAmount] = useState<number>(0)
  const [feeType, setFeeType] = useState<'percentage' | 'fixed'>('percentage')
  const [feeAmount, setFeeAmount] = useState<number>(0)
  const [rejectionReason, setRejectionReason] = useState('')
  const [showIdCard, setShowIdCard] = useState(false)

  const handleCreateUser = () => {
    if (newUser.firstName && newUser.lastName && newUser.email) {
      const user: User = {
        id: (users.length + 1).toString(),
        ...newUser as User,
        role: newUser.role || 'user',
        status: 'pending',
        balance: 0,
        withdrawalLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 },
        sendLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 },
      }
      setUsers([...users, user])
      setNewUser({})
    }
  }

  const handleApproveUser = (userId: string) => {
    const updatedUsers = users.map(user => 
      user.id === userId ? { ...user, status: 'approved' } : user
    )
    setUsers(updatedUsers)
  }

  const handleRejectUser = (userId: string) => {
    if (rejectionReason) {
      const updatedUsers = users.map(user => 
        user.id === userId ? { ...user, status: 'rejected' } : user
      )
      setUsers(updatedUsers)
      setRejectionReason('')
    }
  }

  const handleBalanceChange = () => {
    if (selectedUser) {
      const updatedUsers = users.map(user => 
        user.id === selectedUser.id 
          ? { ...user, balance: balanceAction === 'add' 
              ? user.balance + balanceAmount 
              : user.balance - balanceAmount 
            }
          : user
      )
      setUsers(updatedUsers)
      setSelectedUser(null)
      setBalanceAmount(0)
    }
  }

  const handleLimitChange = (type: 'withdrawal' | 'send', period: 'daily' | 'weekly' | 'monthly' | 'yearly') => {
    if (selectedUser) {
      const updatedUsers = users.map(user => 
        user.id === selectedUser.id 
          ? { 
              ...user, 
              [type === 'withdrawal' ? 'withdrawalLimit' : 'sendLimit']: {
                ...user[type === 'withdrawal' ? 'withdrawalLimit' : 'sendLimit'],
                [period]: feeAmount === -1 ? 'No Limit' : feeAmount
              }
            }
          : user
      )
      setUsers(updatedUsers)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Users Management</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all">
          <TabsList>
            <TabsTrigger value="all">All Users</TabsTrigger>
            <TabsTrigger value="pending">Pending Users</TabsTrigger>
          </TabsList>
          <TabsContent value="all">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>{user.firstName} {user.lastName}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>{user.status}</TableCell>
                    <TableCell>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="mr-2">View Details</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-3xl">
                          <DialogHeader>
                            <DialogTitle>User Details</DialogTitle>
                          </DialogHeader>
                          <ScrollArea className="h-[400px] w-full">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <h3 className="font-bold">Personal Information</h3>
                                <p>Name: {user.firstName} {user.lastName}</p>
                                <p>Username: {user.username}</p>
                                <p>Email: {user.email}</p>
                                <p>Date of Birth: {user.dateOfBirth}</p>
                                <p>Place of Birth: {user.placeOfBirth}</p>
                                <p>Residence: {user.residence}</p>
                                <p>Nationality: {user.nationality}</p>
                              </div>
                              {user.status !== 'pending' && (
                                <div>
                                  <h3 className="font-bold">Account Information</h3>
                                  <p>Status: {user.status}</p>
                                  <p>Balance: ${user.balance}</p>
                                  <h4 className="font-semibold mt-2">Withdrawal Limits</h4>
                                  <p>Daily: ${user.withdrawalLimit.daily}</p>
                                  <p>Weekly: ${user.withdrawalLimit.weekly}</p>
                                  <p>Monthly: ${user.withdrawalLimit.monthly}</p>
                                  <p>Yearly: ${user.withdrawalLimit.yearly}</p>
                                  <h4 className="font-semibold mt-2">Send Limits</h4>
                                  <p>Daily: ${user.sendLimit.daily}</p>
                                  <p>Weekly: ${user.sendLimit.weekly}</p>
                                  <p>Monthly: ${user.sendLimit.monthly}</p>
                                  <p>Yearly: ${user.sendLimit.yearly}</p>
                                </div>
                              )}
                            </div>
                            <div className="mt-4">
                              <h3 className="font-bold">ID Card</h3>
                              <Button onClick={() => setShowIdCard(true)} className="mt-2">View ID Card</Button>
                            </div>
                          </ScrollArea>
                        </DialogContent>
                      </Dialog>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="mr-2">Manage Balance</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Manage Balance</DialogTitle>
                          </DialogHeader>
                          <Select onValueChange={(value) => setBalanceAction(value as 'add' | 'deduct')}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select action" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="add">Add</SelectItem>
                              <SelectItem value="deduct">Deduct</SelectItem>
                            </SelectContent>
                          </Select>
                          <Input
                            type="number"
                            placeholder="Amount"
                            value={balanceAmount}
                            onChange={(e) => setBalanceAmount(Number(e.target.value))}
                          />
                          <Button onClick={handleBalanceChange}>Update Balance</Button>
                        </DialogContent>
                      </Dialog>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline">Set Limits</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Set User Limits</DialogTitle>
                          </DialogHeader>
                          <Tabs defaultValue="withdrawal">
                            <TabsList>
                              <TabsTrigger value="withdrawal">Withdrawal Limits</TabsTrigger>
                              <TabsTrigger value="send">Send Limits</TabsTrigger>
                            </TabsList>
                            <TabsContent value="withdrawal">
                              <div className="space-y-4">
                                {['daily', 'weekly', 'monthly', 'yearly'].map((period) => (
                                  <div key={period}>
                                    <Label>{period.charAt(0).toUpperCase() + period.slice(1)} Limit</Label>
                                    <div className="flex space-x-2">
                                      <Input
                                        type="number"
                                        value={feeAmount}
                                        onChange={(e) => setFeeAmount(Number(e.target.value))}
                                      />
                                      <Button onClick={() => handleLimitChange('withdrawal', period as 'daily' | 'weekly' | 'monthly' | 'yearly')}>Set</Button>
                                    </div>
                                  </div>
                                ))}
                                <Button onClick={() => handleLimitChange('withdrawal', 'daily')}>Set No Limit</Button>
                              </div>
                            </TabsContent>
                            <TabsContent value="send">
                              <div className="space-y-4">
                                {['daily', 'weekly', 'monthly', 'yearly'].map((period) => (
                                  <div key={period}>
                                    <Label>{period.charAt(0).toUpperCase() + period.slice(1)} Limit</Label>
                                    <div className="flex space-x-2">
                                      <Input
                                        type="number"
                                        value={feeAmount}
                                        onChange={(e) => setFeeAmount(Number(e.target.value))}
                                      />
                                      <Button onClick={() => handleLimitChange('send', period as 'daily' | 'weekly' | 'monthly' | 'yearly')}>Set</Button>
                                    </div>
                                  </div>
                                ))}
                                <Button onClick={() => handleLimitChange('send', 'daily')}>Set No Limit</Button>
                              </div>
                            </TabsContent>
                          </Tabs>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>
          <TabsContent value="pending">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.filter(user => user.status === 'pending').map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>{user.firstName} {user.lastName}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="mr-2">View Details</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-3xl">
                          <DialogHeader>
                            <DialogTitle>User Details</DialogTitle>
                          </DialogHeader>
                          <ScrollArea className="h-[400px] w-full">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <h3 className="font-bold">Personal Information</h3>
                                <p>Name: {user.firstName} {user.lastName}</p>
                                <p>Username: {user.username}</p>
                                <p>Email: {user.email}</p>
                                <p>Date of Birth: {user.dateOfBirth}</p>
                                <p>Place of Birth: {user.placeOfBirth}</p>
                                <p>Residence: {user.residence}</p>
                                <p>Nationality: {user.nationality}</p>
                              </div>
                            </div>
                            <div className="mt-4">
                              <h3 className="font-bold">ID Card</h3>
                              <Button onClick={() => setShowIdCard(true)} className="mt-2">View ID Card</Button>
                            </div>
                          </ScrollArea>
                        </DialogContent>
                      </Dialog>
                      <Button variant="outline" className="mr-2" onClick={() => handleApproveUser(user.id)}>
                        Approve
                      </Button>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline">Reject</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Reject User</DialogTitle>
                          </DialogHeader>
                          <Textarea
                            placeholder="Reason for rejection"
                            value={rejectionReason}
                            onChange={(e) => setRejectionReason(e.target.value)}
                          />
                          <Button onClick={() => handleRejectUser(user.id)}>Confirm Rejection</Button>
                        </DialogContent>
                      </Dialog>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>
        </Tabs>
        <Dialog>
          <DialogTrigger asChild>
            <Button className="mt-4">Add New User</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New User</DialogTitle>
            </DialogHeader>
            <ScrollArea className="h-[400px] w-full">
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="firstName" className="text-right">
                    First Name
                  </Label>
                  <Input
                    id="firstName"
                    value={newUser.firstName || ''}
                    onChange={(e) => setNewUser({ ...newUser, firstName: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="lastName" className="text-right">
                    Last Name
                  </Label>
                  <Input
                    id="lastName"
                    value={newUser.lastName || ''}
                    onChange={(e) => setNewUser({ ...newUser, lastName: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="username" className="text-right">
                    Username
                  </Label>
                  <Input
                    id="username"
                    value={newUser.username || ''}
                    onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={newUser.email || ''}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="password" className="text-right">
                    Create Password
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    value={newUser.password || ''}
                    onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="role" className="text-right">
                    User Role
                  </Label>
                  <Select
                    value={newUser.role}
                    onValueChange={(value) => setNewUser({ ...newUser, role: value as 'admin' | 'user' })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Admin</SelectItem>
                      <SelectItem value="user">User</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="dateOfBirth" className="text-right">
                    Date of Birth
                  </Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={newUser.dateOfBirth || ''}
                    onChange={(e) => setNewUser({ ...newUser, dateOfBirth: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="placeOfBirth" className="text-right">
                    Place of Birth
                  </Label>
                  <Input
                    id="placeOfBirth"
                    value={newUser.placeOfBirth || ''}
                    onChange={(e) => setNewUser({ ...newUser, placeOfBirth: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="residence" className="text-right">
                    Residence
                  </Label>
                  <Input
                    id="residence"
                    value={newUser.residence || ''}
                    onChange={(e) => setNewUser({ ...newUser, residence: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="nationality" className="text-right">
                    Nationality
                  </Label>
                  <Input
                    id="nationality"
                    value={newUser.nationality || ''}
                    onChange={(e) => setNewUser({ ...newUser, nationality: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="idCardUpload" className="text-right">
                    ID Card Upload
                  </Label>
                  <Input
                    id="idCardUpload"
                    type="file"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        // In a real application, you would upload this file to your server
                        // and get back a URL. For now, we'll just use a placeholder.
                        setNewUser({ ...newUser, idCardUrl: URL.createObjectURL(file) });
                      }
                    }}
                    className="col-span-3"
                  />
                </div>
              </div>
              <Button onClick={handleCreateUser}>Create User</Button>
            </ScrollArea>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

