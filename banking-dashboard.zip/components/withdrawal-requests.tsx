"use client"

import { useState } from 'react'
import { Transaction } from '@/types/dashboard'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'

// Mock data
const mockWithdrawals: Transaction[] = [
  { id: '1', userId: '1', type: 'withdrawal', amount: 500, status: 'pending', createdAt: '2023-06-01', updatedAt: '2023-06-01' },
  { id: '2', userId: '2', type: 'withdrawal', amount: 1000, status: 'pending', createdAt: '2023-06-02', updatedAt: '2023-06-02' },
]

export function WithdrawalRequests() {
  const [withdrawals, setWithdrawals] = useState<Transaction[]>(mockWithdrawals)
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<Transaction | null>(null)
  const [transactionDetails, setTransactionDetails] = useState({
    reference: '',
    bankName: '',
    accountNumber: '',
    accountName: '',
  })
  const [rejectionReason, setRejectionReason] = useState('')

  const handleApprove = (withdrawal: Transaction) => {
    if (transactionDetails.reference) {
      const updatedWithdrawals = withdrawals.map(w => 
        w.id === withdrawal.id 
          ? { ...w, status: 'approved', ...transactionDetails, updatedAt: new Date().toISOString() }
          : w
      )
      setWithdrawals(updatedWithdrawals)
      setSelectedWithdrawal(null)
      setTransactionDetails({
        reference: '',
        bankName: '',
        accountNumber: '',
        accountName: '',
      })
      // Here you would typically send an email notification to the user
      console.log(`Approved withdrawal for user ${withdrawal.userId}. Reference: ${transactionDetails.reference}`)
    }
  }

  const handleReject = (withdrawalId: string) => {
    if (rejectionReason) {
      const updatedWithdrawals = withdrawals.map(w => 
        w.id === withdrawalId 
          ? { ...w, status: 'rejected', rejectionReason, updatedAt: new Date().toISOString() }
          : w
      )
      setWithdrawals(updatedWithdrawals)
      setRejectionReason('')
      // Here you would typically send an email notification to the user
      console.log(`Rejected withdrawal for user ${withdrawalId}. Reason: ${rejectionReason}`)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Withdrawal Requests</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>User ID</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Created At</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {withdrawals.map((withdrawal) => (
              <TableRow key={withdrawal.id}>
                <TableCell>{withdrawal.userId}</TableCell>
                <TableCell>${withdrawal.amount}</TableCell>
                <TableCell>{withdrawal.status}</TableCell>
                <TableCell>{new Date(withdrawal.createdAt).toLocaleDateString()}</TableCell>
                <TableCell>
                  {withdrawal.status === 'pending' && (
                    <>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="mr-2" onClick={() => setSelectedWithdrawal(withdrawal)}>
                            Approve
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Approve Withdrawal</DialogTitle>
                          </DialogHeader>
                          <Input
                            placeholder="Transaction Reference"
                            value={transactionDetails.reference}
                            onChange={(e) => setTransactionDetails({...transactionDetails, reference: e.target.value})}
                            className="mb-2"
                          />
                          <Input
                            placeholder="Bank Name"
                            value={transactionDetails.bankName}
                            onChange={(e) => setTransactionDetails({...transactionDetails, bankName: e.target.value})}
                            className="mb-2"
                          />
                          <Input
                            placeholder="Account Number"
                            value={transactionDetails.accountNumber}
                            onChange={(e) => setTransactionDetails({...transactionDetails, accountNumber: e.target.value})}
                            className="mb-2"
                          />
                          <Input
                            placeholder="Account Name"
                            value={transactionDetails.accountName}
                            onChange={(e) => setTransactionDetails({...transactionDetails, accountName: e.target.value})}
                            className="mb-2"
                          />
                          <Button onClick={() => handleApprove(withdrawal)}>Confirm Approval</Button>
                        </DialogContent>
                      </Dialog>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline">Reject</Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Reject Withdrawal</DialogTitle>
                          </DialogHeader>
                          <Textarea
                            placeholder="Reason for rejection"
                            value={rejectionReason}
                            onChange={(e) => setRejectionReason(e.target.value)}
                          />
                          <Button onClick={() => handleReject(withdrawal.id)}>Confirm Rejection</Button>
                        </DialogContent>
                      </Dialog>
                    </>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

