"use client"

import { useState } from 'react'
import { Plus } from 'lucide-react'
import { Bank, User } from '@/types/dashboard'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Checkbox } from "@/components/ui/checkbox"
import { ScrollArea } from "@/components/ui/scroll-area"

// Mock data
const mockBanks: Bank[] = [
  { id: '1', name: 'Commercial Bank of Ethiopia', assignedUsers: ['1', '2'] },
  { id: '2', name: 'Awash Bank', assignedUsers: ['3'] },
]

const mockUsers: User[] = [
  { id: '1', firstName: 'John', lastName: 'Doe', username: 'johndoe', email: 'john@example.com', dateOfBirth: '1990-01-01', placeOfBirth: 'Addis Ababa', residence: 'Addis Ababa', nationality: 'Ethiopian', idCardUrl: '', role: 'user', status: 'approved', balance: 1000, withdrawalLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 }, sendLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 } },
  { id: '2', firstName: 'Jane', lastName: 'Doe', username: 'janedoe', email: 'jane@example.com', dateOfBirth: '1992-05-15', placeOfBirth: 'Bahir Dar', residence: 'Addis Ababa', nationality: 'Ethiopian', idCardUrl: '', role: 'user', status: 'approved', balance: 2000, withdrawalLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 }, sendLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 } },
  { id: '3', firstName: 'Bob', lastName: 'Smith', username: 'bobsmith', email: 'bob@example.com', dateOfBirth: '1988-11-30', placeOfBirth: 'Mekelle', residence: 'Addis Ababa', nationality: 'Ethiopian', idCardUrl: '', role: 'user', status: 'approved', balance: 1500, withdrawalLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 }, sendLimit: { daily: 1000, weekly: 5000, monthly: 20000, yearly: 100000 } },
]

export function BanksManagement() {
  const [banks, setBanks] = useState<Bank[]>(mockBanks)
  const [newBankName, setNewBankName] = useState('')
  const [selectedBank, setSelectedBank] = useState<Bank | null>(null)
  const [selectedUsers, setSelectedUsers] = useState<string[]>([])
  const [assignAllUsers, setAssignAllUsers] = useState(false)

  const handleCreateBank = () => {
    if (newBankName) {
      const newBank: Bank = {
        id: (banks.length + 1).toString(),
        name: newBankName,
        assignedUsers: [],
      }
      setBanks([...banks, newBank])
      setNewBankName('')
    }
  }

  const handleAssignUsers = () => {
    if (selectedBank) {
      const updatedBanks = banks.map(bank => 
        bank.id === selectedBank.id 
          ? { ...bank, assignedUsers: assignAllUsers ? mockUsers.map(u => u.id) : selectedUsers }
          : bank
      )
      setBanks(updatedBanks)
      setSelectedBank(null)
      setSelectedUsers([])
      setAssignAllUsers(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Banks Management</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-2 mb-4">
          <Input
            placeholder="Enter bank name"
            value={newBankName}
            onChange={(e) => setNewBankName(e.target.value)}
          />
          <Button onClick={handleCreateBank}>
            <Plus className="mr-2 h-4 w-4" /> Create Bank
          </Button>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Bank Name</TableHead>
              <TableHead>Assigned Users</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {banks.map((bank) => (
              <TableRow key={bank.id}>
                <TableCell>{bank.name}</TableCell>
                <TableCell>{bank.assignedUsers.length}</TableCell>
                <TableCell>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" onClick={() => setSelectedBank(bank)}>
                        Assign Users
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Assign Users to {bank.name}</DialogTitle>
                      </DialogHeader>
                      <div className="flex items-center space-x-2 mb-4">
                        <Checkbox
                          id="assignAll"
                          checked={assignAllUsers}
                          onCheckedChange={(checked) => {
                            setAssignAllUsers(checked as boolean)
                            if (checked) {
                              setSelectedUsers(mockUsers.map(u => u.id))
                            } else {
                              setSelectedUsers([])
                            }
                          }}
                        />
                        <label htmlFor="assignAll">Assign all users</label>
                      </div>
                      {!assignAllUsers && (
                        <ScrollArea className="h-[200px] overflow-y-auto">
                          {mockUsers.map((user) => (
                            <div key={user.id} className="flex items-center space-x-2 mb-2">
                              <Checkbox
                                id={`user-${user.id}`}
                                checked={selectedUsers.includes(user.id)}
                                onCheckedChange={(checked) => {
                                  if (checked) {
                                    setSelectedUsers([...selectedUsers, user.id])
                                  } else {
                                    setSelectedUsers(selectedUsers.filter(id => id !== user.id))
                                  }
                                }}
                              />
                              <label htmlFor={`user-${user.id}`}>{user.firstName} {user.lastName}</label>
                            </div>
                          ))}
                        </ScrollArea>
                      )}
                      <Button onClick={handleAssignUsers}>Assign</Button>
                    </DialogContent>
                  </Dialog>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

