"use client"

import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis } from "recharts"

const data = [
  { date: "Jan 1", transactions: 150 },
  { date: "Jan 8", transactions: 200 },
  { date: "Jan 15", transactions: 250 },
  { date: "Jan 24", transactions: 280 },
  { date: "Jan 31", transactions: 240 },
  { date: "Feb 1", transactions: 260 }
]

export function TransactionsChart() {
  return (
    <div className="h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis
            dataKey="date"
            stroke="#4B5563"
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip 
            contentStyle={{ 
              background: '#1F2937',
              border: 'none',
              borderRadius: '8px',
              color: 'white'
            }}
          />
          <Line
            type="monotone"
            dataKey="transactions"
            stroke="#3B82F6"
            strokeWidth={2}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

