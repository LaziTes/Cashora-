export interface User {
  id: string;
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  dateOfBirth: string;
  placeOfBirth: string;
  residence: string;
  nationality: string;
  idCardUrl: string;
  role: 'admin' | 'user';
  status: 'pending' | 'approved' | 'rejected';
  balance: number;
  withdrawalLimit: {
    daily: number;
    weekly: number;
    monthly: number;
  };
  sendLimit: {
    daily: number;
    weekly: number;
    monthly: number;
  };
}

export interface Bank {
  id: string;
  name: string;
  assignedUsers: string[]; // Array of user IDs
}

export interface Transaction {
  id: string;
  userId: string;
  type: 'deposit' | 'withdrawal' | 'send';
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt: string;
  reference?: string;
}

export interface Email {
  id: string;
  to: string[] | 'all';
  subject: string;
  body: string;
  sentAt: string;
}

export interface Settings {
  withdrawalFee: {
    type: 'percentage' | 'fixed';
    value: number;
  };
  sendFee: {
    type: 'percentage' | 'fixed';
    value: number;
  };
}

