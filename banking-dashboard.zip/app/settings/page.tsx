import { SettingsManagement } from "@/components/settings"

export default function SettingsPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Settings</h1>
      <SettingsManagement />
    </div>
  )
}

