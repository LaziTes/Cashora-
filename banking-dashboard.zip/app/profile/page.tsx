import { ProfileComponent } from "@/components/profile"

export default function ProfilePage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Admin Profile</h1>
      <ProfileComponent />
    </div>
  )
}

