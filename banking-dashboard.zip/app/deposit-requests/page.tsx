import { DepositRequests } from "@/components/deposit-requests"

export default function DepositRequestsPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Deposit Requests</h1>
      <DepositRequests />
    </div>
  )
}

