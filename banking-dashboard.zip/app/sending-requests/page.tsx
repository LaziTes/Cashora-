import { SendingRequests } from "@/components/sending-requests"

export default function SendingRequestsPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Sending Requests</h1>
      <SendingRequests />
    </div>
  )
}

