import { EmailManagement } from "@/components/email-management"

export default function EmailsPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Email Management</h1>
      <EmailManagement />
    </div>
  )
}

