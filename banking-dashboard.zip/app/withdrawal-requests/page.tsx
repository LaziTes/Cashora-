import { WithdrawalRequests } from "@/components/withdrawal-requests"

export default function WithdrawalRequestsPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-4">Withdrawal Requests</h1>
      <WithdrawalRequests />
    </div>
  )
}

