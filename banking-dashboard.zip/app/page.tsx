import { BanknoteIcon as Bank, DollarSign, Send, Users } from 'lucide-react'

import { MetricCardComponent } from "@/components/metric-card"
import { TransactionsChart } from "@/components/transactions-chart"
import { TransactionsTable } from "@/components/transactions-table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MainNav } from "@/components/main-nav"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"

const metrics = [
  {
    label: "Total Deposit",
    value: "$10,000,000",
    icon: DollarSign,
  },
  {
    label: "Total Users",
    value: "230",
    icon: Users,
  },
  {
    label: "Total Withdrawals",
    value: "$10,000,000",
    icon: Send,
  },
  {
    label: "Total Sendings",
    value: "$10,000,000",
    icon: Send,
  },
]

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-[#0A0B14]">
      <div className="p-8">
        <div className="flex-1 space-y-8">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {metrics.map((metric) => (
              <MetricCardComponent key={metric.label} data={metric} />
            ))}
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
            <Card className="col-span-3 bg-[#0B0D1D] border-[#1D2144]">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-lg font-medium text-white">Banks</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-white">Commercial Bank Of Ethiopia</h3>
                      <p className="text-xs text-gray-400">200 Users</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-white">Awash Bank</h3>
                      <p className="text-xs text-gray-400">100 Users</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="col-span-4 bg-[#0B0D1D] border-[#1D2144]">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-medium text-white">Transactions Overview</CardTitle>
                  <div className="text-sm text-gray-400">257</div>
                </div>
              </CardHeader>
              <CardContent className="pl-2">
                <TransactionsChart />
              </CardContent>
            </Card>
          </div>

          <Card className="bg-[#0B0D1D] border-[#1D2144]">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-medium text-white">Recent Transactions</CardTitle>
                <Button variant="link" className="text-blue-400 hover:text-blue-300">
                  All Transactions
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <TransactionsTable />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

