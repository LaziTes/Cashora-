"use client"

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Mock data for deposit history
const mockDepositHistory = [
  { id: 1, amount: 1000, date: '2023-05-01', status: 'completed', method: 'Bank Transfer', reference: 'DEP001' },
  { id: 2, amount: 1500, date: '2023-05-15', status: 'pending', method: 'Credit Card', reference: 'DEP002' },
]

export function DepositForm() {
  const [fullName, setFullName] = useState('')
  const [amount, setAmount] = useState('')
  const [receipt, setReceipt] = useState<File | null>(null)
  const [depositHistory, setDepositHistory] = useState(mockDepositHistory)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the deposit request to your backend
    console.log('Deposit submitted:', { fullName, amount, receipt })
    // For demo purposes, let's add this to our deposit history
    setDepositHistory([
      {
        id: depositHistory.length + 1,
        amount: parseFloat(amount),
        date: new Date().toISOString().split('T')[0],
        status: 'pending',
        method: 'Unknown', // Add method and reference for new deposits
        reference: 'DEP' + (depositHistory.length + 1).toString().padStart(3, '0')
      },
      ...depositHistory
    ])
    // Reset form
    setFullName('')
    setAmount('')
    setReceipt(null)
  }

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Deposit Request Form</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fullName">Full Name</Label>
              <Input
                id="fullName"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="receipt">Receipt Upload</Label>
              <Input
                id="receipt"
                type="file"
                onChange={(e) => setReceipt(e.target.files?.[0] || null)}
                required
              />
            </div>
            <Button type="submit">Submit Deposit Request</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Deposit History</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Method</TableHead>
                <TableHead>Reference</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {depositHistory.map((deposit) => (
                <TableRow key={deposit.id}>
                  <TableCell>{deposit.id}</TableCell>
                  <TableCell>${deposit.amount.toFixed(2)}</TableCell>
                  <TableCell>{deposit.date}</TableCell>
                  <TableCell>{deposit.status}</TableCell>
                  <TableCell>{deposit.method}</TableCell>
                  <TableCell>{deposit.reference}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

