"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

// Mock data
// const mockTransactions = [
//   { id: 1, type: 'deposit', amount: 1000, date: '2023-05-01', status: 'completed', recipient: 'Self' },
//   { id: 2, type: 'withdrawal', amount: 500, date: '2023-05-05', status: 'completed', recipient: 'Bank Account' },
//   { id: 3, type: 'send', amount: 200, date: '2023-05-10', status: 'completed', recipient: 'John Doe' },
//   { id: 4, type: 'deposit', amount: 1500, date: '2023-05-15', status: 'pending', recipient: 'Self' },
//   { id: 5, type: 'withdrawal', amount: 300, date: '2023-05-20', status: 'completed', recipient: 'Bank Account' },
//   { id: 6, type: 'send', amount: 100, date: '2023-05-25', status: 'failed', recipient: 'Jane Smith' },
// ]

const chartData = [
  { name: 'Jan', deposits: 3000, withdrawals: 1400, sends: 800 },
  { name: 'Feb', deposits: 2500, withdrawals: 1200, sends: 1000 },
  { name: 'Mar', deposits: 3500, withdrawals: 1600, sends: 1200 },
  { name: 'Apr', deposits: 4000, withdrawals: 1800, sends: 1500 },
  { name: 'May', deposits: 3800, withdrawals: 2000, sends: 1300 },
]

export function TransactionHistory() {
  const [transactions, setTransactions] = useState([])
  const [filter, setFilter] = useState({ type: 'all', status: 'all', search: '' })

  useEffect(() => {
    // Simulating API call to fetch transactions
    const fetchTransactions = async () => {
      // In a real application, this would be an API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      setTransactions([
        { id: 1, type: 'deposit', amount: 1000, date: '2023-05-01', status: 'completed', recipient: 'Self' },
        { id: 2, type: 'withdrawal', amount: 500, date: '2023-05-05', status: 'completed', recipient: 'Bank Account' },
        { id: 3, type: 'send', amount: 200, date: '2023-05-10', status: 'completed', recipient: 'John Doe' },
        { id: 4, type: 'deposit', amount: 1500, date: '2023-05-15', status: 'pending', recipient: 'Self' },
        { id: 5, type: 'withdrawal', amount: 300, date: '2023-05-20', status: 'completed', recipient: 'Bank Account' },
        { id: 6, type: 'send', amount: 100, date: '2023-05-25', status: 'failed', recipient: 'Jane Smith' },
      ])
    }
    fetchTransactions()
  }, [])

  const filteredTransactions = transactions.filter(t => 
    (filter.type === 'all' || t.type === filter.type) &&
    (filter.status === 'all' || t.status === filter.status) &&
    (filter.search === '' || 
     t.id.toString().includes(filter.search) || 
     t.amount.toString().includes(filter.search) || 
     t.recipient.toLowerCase().includes(filter.search.toLowerCase()))
  )

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-500'
      case 'pending': return 'bg-yellow-500'
      case 'failed': return 'bg-red-500'
      default: return 'bg-gray-500'
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Transaction History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-wrap gap-4 mb-4">
          <Select onValueChange={(value) => setFilter(prev => ({...prev, type: value}))}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="deposit">Deposit</SelectItem>
              <SelectItem value="withdrawal">Withdrawal</SelectItem>
              <SelectItem value="send">Send</SelectItem>
            </SelectContent>
          </Select>
          <Select onValueChange={(value) => setFilter(prev => ({...prev, status: value}))}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>
          <Input 
            placeholder="Search by ID, amount, or recipient" 
            value={filter.search}
            onChange={(e) => setFilter(prev => ({...prev, search: e.target.value}))}
            className="w-[300px]"
          />
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Recipient</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTransactions.map((transaction) => (
              <TableRow key={transaction.id}>
                <TableCell>{transaction.id}</TableCell>
                <TableCell className="capitalize">{transaction.type}</TableCell>
                <TableCell>${transaction.amount.toFixed(2)}</TableCell>
                <TableCell>{transaction.date}</TableCell>
                <TableCell>
                  <Badge className={getStatusColor(transaction.status)}>
                    {transaction.status}
                  </Badge>
                </TableCell>
                <TableCell>{transaction.recipient}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  )
}

