"use client"

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Mock data for send money history
const mockSendHistory = [
  { id: 1, recipient: 'john@example.com', amount: 100, date: '2023-05-01', status: 'completed', fee: 1.50, totalAmount: 101.50 },
  { id: 2, recipient: 'jane@example.com', amount: 200, date: '2023-05-15', status: 'pending', fee: 2.00, totalAmount: 202.00 },
]

export function SendMoneyForm() {
  const [recipient, setRecipient] = useState('')
  const [amount, setAmount] = useState('')
  const [sendHistory, setSendHistory] = useState(mockSendHistory)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the money transfer request to your backend
    console.log('Money transfer submitted:', { recipient, amount })
    // For demo purposes, let's add this to our send history
    setSendHistory([
      {
        id: sendHistory.length + 1,
        recipient,
        amount: parseFloat(amount),
        date: new Date().toISOString().split('T')[0],
        status: 'pending',
        fee: 0, // Add fee and totalAmount here.  Adjust as needed for fee calculation.
        totalAmount: parseFloat(amount) // Adjust as needed for fee calculation.
      },
      ...sendHistory
    ])
    // Reset form
    setRecipient('')
    setAmount('')
  }

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Send Money Form</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="recipient">Recipient (Username or Email)</Label>
              <Input
                id="recipient"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </div>
            <Button type="submit">Send Money</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Send Money History</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Recipient</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Fee</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sendHistory.map((transaction) => (
                <TableRow key={transaction.id}>
                  <TableCell>{transaction.id}</TableCell>
                  <TableCell>{transaction.recipient}</TableCell>
                  <TableCell>${transaction.amount.toFixed(2)}</TableCell>
                  <TableCell>${transaction.fee.toFixed(2)}</TableCell>
                  <TableCell>${transaction.totalAmount.toFixed(2)}</TableCell>
                  <TableCell>{transaction.date}</TableCell>
                  <TableCell>{transaction.status}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

