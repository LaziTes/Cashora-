"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useRouter } from 'next/navigation'
import { BarChart3, Send, LogOut, User, CreditCard, PiggyBank, History, MessageCircle } from 'lucide-react'

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export function UserPortalNav() {
  const pathname = usePathname()
  const router = useRouter()

  const routes = [
    {
      label: "Dashboard",
      icon: BarChart3,
      href: "/user-portal",
      color: "text-sky-500"
    },
    {
      label: "Transaction History",
      icon: History,
      href: "/user-portal/history",
      color: "text-violet-500"
    },
    {
      label: "Deposit",
      icon: PiggyBank,
      href: "/user-portal/deposit",
      color: "text-green-500"
    },
    {
      label: "Withdraw",
      icon: CreditCard,
      href: "/user-portal/withdraw",
      color: "text-red-500"
    },
    {
      label: "Send",
      icon: Send,
      href: "/user-portal/send",
      color: "text-blue-500"
    },
    {
      label: "Customer Support",
      icon: MessageCircle,
      href: "#",
      color: "text-purple-500"
    },
    {
      label: "Profile",
      icon: User,
      href: "/user-portal/profile",
      color: "text-yellow-500"
    }
  ]

  const handleLogout = () => {
    console.log('Logging out...')
    router.push('/login')
  }

  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden lg:flex w-64 flex-col gap-4 border-r bg-background">
        <div className="flex h-16 items-center border-b px-4">
          <Link href="/user-portal" className="flex items-center gap-2 font-semibold">
            <BarChart3 className="h-6 w-6" />
            <span>Cashora User Portal</span>
          </Link>
        </div>
        <nav className="flex flex-col gap-1 px-2">
          {routes.map((route) => (
            <Button
              key={route.href}
              variant={pathname === route.href ? "secondary" : "ghost"}
              className={cn("justify-start gap-2", pathname === route.href && "bg-muted")}
              asChild
            >
              <Link href={route.href}>
                <route.icon className={cn("h-5 w-5", route.color)} />
                {route.label}
              </Link>
            </Button>
          ))}
        </nav>
        <div className="mt-auto p-4">
          <Button onClick={handleLogout} className="w-full">
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
      {/* Mobile Sidebar */}
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="lg:hidden">
            <BarChart3 className="h-6 w-6" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <div className="flex h-16 items-center border-b px-4">
            <Link href="/user-portal" className="flex items-center gap-2 font-semibold">
              <BarChart3 className="h-6 w-6" />
              <span>Cashora User Portal</span>
            </Link>
          </div>
          <nav className="flex flex-col gap-1 p-2">
            {routes.map((route) => (
              <Button
                key={route.href}
                variant={pathname === route.href ? "secondary" : "ghost"}
                className={cn("justify-start gap-2", pathname === route.href && "bg-muted")}
                asChild
              >
                <Link href={route.href}>
                  <route.icon className={cn("h-5 w-5", route.color)} />
                  {route.label}
                </Link>
              </Button>
            ))}
          </nav>
          <div className="mt-auto p-4">
            <Button onClick={handleLogout} className="w-full">
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}

