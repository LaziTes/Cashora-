"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { DollarSign, ArrowUpRight, ArrowDownRight, CreditCard } from 'lucide-react'

// Mock data - replace with real data fetching in a production environment
const mockUserData = {
  balance: 5000,
  totalSent: 2000,
  totalWithdrawn: 1500,
  totalDeposited: 8500,
  transactionHistory: [
    { month: 'Jan', deposits: 1000, withdrawals: 500, sends: 300 },
    { month: 'Feb', deposits: 1500, withdrawals: 700, sends: 400 },
    { month: 'Mar', deposits: 1200, withdrawals: 600, sends: 350 },
    { month: 'Apr', deposits: 2000, withdrawals: 800, sends: 500 },
    { month: 'May', deposits: 1800, withdrawals: 750, sends: 450 },
    { month: 'Jun', deposits: 2200, withdrawals: 900, sends: 550 },
  ]
}

export function UserDashboard() {
  const [userData, setUserData] = useState(mockUserData)

  // Simulating data fetching
  useEffect(() => {
    // In a real application, you would fetch user data here
    setUserData(mockUserData)
  }, [])

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Balance</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${userData.balance.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Current account balance</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Deposited</CardTitle>
            <ArrowUpRight className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${userData.totalDeposited.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Lifetime deposits</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Withdrawn</CardTitle>
            <ArrowDownRight className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${userData.totalWithdrawn.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Lifetime withdrawals</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sent</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${userData.totalSent.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">Lifetime sent amount</p>
          </CardContent>
        </Card>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Transaction Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={userData.transactionHistory}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="deposits" fill="#8884d8" name="Deposits" />
                <Bar dataKey="withdrawals" fill="#82ca9d" name="Withdrawals" />
                <Bar dataKey="sends" fill="#ffc658" name="Sends" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

