"use client"

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data for withdrawal history
const mockWithdrawalHistory = [
  { id: 1, amount: 500, date: '2023-05-01', status: 'completed', bankName: 'Bank 1', accountNumber: '**** 1234' },
  { id: 2, amount: 1000, date: '2023-05-15', status: 'pending', bankName: 'Bank 2', accountNumber: '**** 5678' },
]

export function WithdrawForm() {
  const [amount, setAmount] = useState('')
  const [bankName, setBankName] = useState('')
  const [accountNumber, setAccountNumber] = useState('')
  const [withdrawalHistory, setWithdrawalHistory] = useState(mockWithdrawalHistory)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the withdrawal request to your backend
    console.log('Withdrawal submitted:', { amount, bankName, accountNumber })
    // For demo purposes, let's add this to our withdrawal history
    setWithdrawalHistory([
      {
        id: withdrawalHistory.length + 1,
        amount: parseFloat(amount),
        date: new Date().toISOString().split('T')[0],
        status: 'pending',
        bankName: bankName,
        accountNumber: accountNumber.slice(-4).padStart(accountNumber.length, '*')
      },
      ...withdrawalHistory
    ])
    // Reset form
    setAmount('')
    setBankName('')
    setAccountNumber('')
  }

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Withdrawal Request Form</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="bankName">Bank Name</Label>
              <Select onValueChange={setBankName} value={bankName}>
                <SelectTrigger id="bankName">
                  <SelectValue placeholder="Select bank" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Bank 1">Bank 1</SelectItem>
                  <SelectItem value="Bank 2">Bank 2</SelectItem>
                  <SelectItem value="Bank 3">Bank 3</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="accountNumber">Account Number</Label>
              <Input
                id="accountNumber"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                required
              />
            </div>
            <Button type="submit">Submit Withdrawal Request</Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Withdrawal History</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Bank</TableHead>
                <TableHead>Account</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {withdrawalHistory.map((withdrawal) => (
                <TableRow key={withdrawal.id}>
                  <TableCell>{withdrawal.id}</TableCell>
                  <TableCell>${withdrawal.amount.toFixed(2)}</TableCell>
                  <TableCell>{withdrawal.date}</TableCell>
                  <TableCell>{withdrawal.status}</TableCell>
                  <TableCell>{withdrawal.bankName}</TableCell>
                  <TableCell>{withdrawal.accountNumber}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

