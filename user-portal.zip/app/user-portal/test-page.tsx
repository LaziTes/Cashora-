export default function TestPage() {
  return (
    <div>
      <h1>Test Page</h1>
      <p>If you can see this, the routing is working correctly.</p>
    </div>
  )
}

