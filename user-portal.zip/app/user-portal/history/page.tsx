import { TransactionHistory } from "@/components/user-portal/transaction-history"

export default function TransactionHistoryPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Transaction History</h1>
      <TransactionHistory />
    </div>
  )
}

