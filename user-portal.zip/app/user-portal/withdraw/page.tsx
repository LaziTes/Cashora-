import { WithdrawForm } from "@/components/user-portal/withdraw-form"

export default function WithdrawPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Withdraw</h1>
      <WithdrawForm />
    </div>
  )
}

