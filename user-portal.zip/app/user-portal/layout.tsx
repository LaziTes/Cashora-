import type { Metadata } from "next"
import { Inter } from 'next/font/google'
import "../globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { UserPortalNav } from "@/components/user-portal/user-portal-nav"
import { ThemeToggle } from "@/components/theme-toggle"
import { CustomerSupportSidebar } from "@/components/user-portal/customer-support-sidebar"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Cashora User Portal",
  description: "User portal for Cashora banking services",
}

export default function UserPortalLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          <div className="flex h-screen overflow-hidden bg-background">
            <UserPortalNav />
            <div className="flex-1 flex flex-col">
              <header className="flex h-16 items-center justify-between border-b px-4">
                <div className="flex items-center gap-4 lg:hidden">
                  <UserPortalNav />
                </div>
                <div className="ml-auto flex items-center gap-4">
                  <ThemeToggle />
                </div>
              </header>
              <main className="flex-1 overflow-auto p-6">
                <div className="mx-auto max-w-7xl">
                  {children}
                </div>
              </main>
            </div>
            <CustomerSupportSidebar />
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}

