import { UserDashboard } from "@/components/user-portal/user-dashboard"

export default function UserPortalPage() {
  return (
    <div className="w-full">
      <h1 className="text-3xl font-bold mb-6">User Dashboard</h1>
      <UserDashboard />
    </div>
  )
}

