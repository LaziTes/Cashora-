import { DepositForm } from "@/components/user-portal/deposit-form"

export default function DepositPage() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Deposit</h1>
      <DepositForm />
    </div>
  )
}

